/* 
 * File:   config.h
 * Author: Admin
 *
 * Created on March 20, 2024, 10:42 AM
 */

#ifndef CONFIG_H
#define	CONFIG_H
#endif

// DSPIC30F3011 Configuration Bit Settings

// 'C' source line config statements

// FOSC
#pragma config FOSC_FOSFPR = XT         // Oscillator (XT)
#pragma config FOSC_FCKSMEN = CSW_FSCM_OFF// Clock Switching and Monitor (Sw Disabled, Mon Disabled)

// FWDT
#pragma config FWDT_FWPSB = WDTPSB_16   // WDT Prescaler B (1:16)
#pragma config FWDT_FWPSA = WDTPSA_512  // WDT Prescaler A (1:512)
#pragma config FWDT_WDT = WDT_OFF       // Watchdog Timer (Disabled)

// FBORPOR
#pragma config FBORPOR_FPWRT = PWRT_64  // POR Timer Value (64ms)
#pragma config FBORPOR_BODENV = BORV20  // Brown Out Voltage (Reserved)
#pragma config FBORPOR_BOREN = PBOR_ON  // PBOR Enable (Enabled)
#pragma config FBORPOR_LPOL = PWMxL_ACT_HI// Low-side PWM Output Polarity (Active High)
#pragma config FBORPOR_HPOL = PWMxH_ACT_HI// High-side PWM Output Polarity (Active High)
#pragma config FBORPOR_PWMPIN = RST_IOPIN// PWM Output Pin Reset (Control with PORT/TRIS regs)
#pragma config FBORPOR_MCLRE = MCLR_EN  // Master Clear Enable (Enabled)

// FGS
#pragma config FGS_GWRP = GWRP_OFF      // General Code Segment Write Protect (Disabled)
#pragma config FGS_GCP = CODE_PROT_OFF  // General Segment Code Protection (Disabled)

// FICD
#pragma config FICD_ICS = ICS_PGD       // Comm Channel Select (Use PGC/EMUC and PGD/EMUD)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>




