/* 
 * File:   lcd.h
 * Author: Admin
 *
 * Created on March 24, 2024, 5:14 PM
 */

#ifndef LCD_H
#define	LCD_H

#endif	/* LCD_H */

#define FOSC    10000000UL
#define FCY     FOSC/4

#include <xc.h>
#include <libpic30.h>

#define LCD_RS      LATEbits.LATE5
#define LCD_EN      LATEbits.LATE4
#define LCD_PORT    LATE

void lcd_command(uint8_t command);
void lcd_data(uint8_t command);
void lcd_position(uint8_t x, uint8_t y);
void lcd_text(uint8_t *text);
void lcd_clear(void);
void lcd_init(void);