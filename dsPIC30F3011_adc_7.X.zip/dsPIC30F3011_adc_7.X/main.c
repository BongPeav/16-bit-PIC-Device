/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 27, 2024, 3:39 PM
 */

#define FOSC    10000000UL
#define FCY     FOSC/4

#include <xc.h>
#include <libpic30.h>
#include <stdio.h>
#include "config.h"
#include "lcd.h"

uint16_t adc_value = 0;
uint16_t temperature=0;

void __attribute__((__interrupt__)) _ADCInterrupt(void){
    adc_value = ADCBUF0;
    IFS0bits.ADIF=0;
}

void main(void) {
    /*all PORTB = Digital; RB2 analog*/
    ADPCFG = 0xFFFE;
    /*SSRC bit = 010 implies GP TMR3
     * compare ends sampling and starts converting
     */
    ADCON1 = 0x0040;
    /*
     * Connect RB2/AN2 as CH0 input ..
     * in this example RB2/AN2 is the input
     */
    ADCHS = 0x0000;
    ADCSSL = 0;
    /*
     * Sampling time is TMR3, Tad = internal Tcy/2
     */
    ADCON3 = 0x0000;
    /*
     * Interrupt after 2 conversions
     */
    ADCON2 = 0x0004;
    /*
     * Set TMR3 to time out every 125 milliseconds
     */
    TMR3 = 0x0000;
    PR3 = 0x3FFF;
    T3CON = 0x8010;
    /*Turn ADC ON*/
    ADCON1bits.ADON = 1;
    /*Start auto sampling every 125 milliseconds*/
    ADCON1bits.ASAM = 1;
    
    lcd_init();
    lcd_clear();
    /*Enable ADC Interrupt Default Priority if 0x04*/
    IEC0bits.ADIE=1;
    IFS0bits.ADIF=0;
    //IPC2bits.ADIP = 7;
    while(1){        
        lcd_position(0,0);
        temperature = (500*adc_value)/1023;
        lcd_text("Temperature:");
        lcd_position(0,1);
        uint8_t msg[16];
        sprintf(msg,"AN0/RB0: %3d%cC",temperature,223);
        lcd_text(msg);
        __delay_ms(100);
    }
    return;
}

