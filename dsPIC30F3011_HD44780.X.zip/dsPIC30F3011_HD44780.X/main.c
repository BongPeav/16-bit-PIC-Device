/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 22, 2024, 4:04 PM
 */

#define FOSC    10000000UL
#define FCY     FOSC/4

#include <xc.h>
#include <libpic30.h>
#include <stdio.h>
#include "config.h"

#define LCD_RS      LATEbits.LATE5
#define LCD_EN      LATEbits.LATE4
#define LCD_PORT    LATE

void lcd_command(uint8_t command){
    uint8_t data;
    data = command>>4;
    
    LCD_PORT=data&0x000F;
    LCD_RS = 0;
    LCD_EN = 1;
    __delay_us(100);
    LCD_EN = 0;
    __delay_us(100);
    
    data = command&0x0F;  
    LCD_PORT = data&0x000F;
    LCD_RS=0;
    LCD_EN = 1;
    __delay_us(100);
    LCD_EN = 0;
    __delay_us(100);
}

void lcd_data(uint8_t command){
    uint8_t data;
    data = command>>4;
    
    LCD_PORT = data&0x000F;
    LCD_RS = 1;
    LCD_EN = 1;
    __delay_us(100);
    LCD_EN = 0;
    __delay_us(100);
    
    data = command&0x0F;
    LCD_PORT = data&0x000F;
    LCD_RS = 1;
    LCD_EN = 1;
    __delay_us(100);
    LCD_EN = 0;
    __delay_us(100);
}

void lcd_position(uint8_t x, uint8_t y){
    uint8_t vertical[]={0x80,0xC0};
    lcd_command(vertical[y]+x);
}

void lcd_text(uint8_t *text){
    while(*text) lcd_data(*text++);
}

void lcd_clear(void){
    lcd_command(0x01);
    __delay_ms(10);
    lcd_command(0x0C);
}

void lcd_init(void){
    PORTF=0;
    LATF=0;
    TRISF=0;
    LCD_PORT=0;
    PORTE=0;
    TRISE=0x0000;
    lcd_command(0x33);
    lcd_command(0x32);
    lcd_command(0x28);
    lcd_command(0x0F);
    lcd_command(0x01);
    __delay_ms(10);
    lcd_command(0x06);
    __delay_ms(10);
}

 uint8_t hours=0, minutes=0, seconds=0;
    uint16_t days=0;
    uint8_t msg[10];
    
void main(void) {
   
    lcd_init();
    lcd_text("HELLO WORLD!");
    lcd_position(0,1);
    lcd_text("dsPIC30F3011");
    __delay_ms(5000);
    lcd_clear();
    while(1){
        lcd_position(0,0);
        lcd_text("DAYS : ");
        sprintf(msg,"%d",days);
        lcd_text(msg);
        
        sprintf(msg,"TIME :%02d:%02d:%02d",hours,minutes,seconds);
        lcd_position(0,1);
        lcd_text(msg);
        seconds++;
        if(seconds>59){seconds=0; minutes++;}
        if(minutes>59){minutes=0; hours++;}
        if(hours>23){hours=0; days++;}
        __delay_ms(250);
    }
    return;
}
