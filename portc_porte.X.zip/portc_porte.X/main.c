/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 20, 2024, 1:53 PM
 */

#define FOSC    10000000UL
#define FCY     FOSC/4

#include <xc.h>
#include <libpic30.h>
#include "config.h"

#define CN0 PORTCbits.RC14
#define CN1 PORTCbits.RC13
#define LD0 PORTEbits.RE1
#define LD1 PORTEbits.RE2

void main(void) {
    PORTE=0;
    LATE=0;
    PORTC=0;
    LATC=0;
    TRISE=0;
    /*RC14:RC13 As Input*/
    TRISCbits.TRISC13=1;
    TRISCbits.TRISC14=1;
    /*Enable Pull-Up on Input Change*/
    CNPU1bits.CN0PUE=1;
    CNPU1bits.CN1PUE=1;
    while(1){
        if(CN0==0){
            __delay_ms(250);
            LD0^=1;
        }
        if(CN1==0){
            __delay_ms(250);
            LD1^=1;
        }
    }
    return;
}
