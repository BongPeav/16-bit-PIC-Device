/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 21, 2024, 9:01 PM
 */

#define FOSC    10000000UL
#define FCY     FOSC/4

#include <xc.h>
#include <libpic30.h>
#include "config.h"

#define CN0 PORTCbits.RC14
#define CN1 PORTCbits.RC13
#define LD0 LATEbits.LATE1
#define LD1 LATEbits.LATE2

void __attribute__((__interrupt__)) _CNInterrupt(void){
    if(CN0==0) LD0^=1;
    if(CN1==0) LD1^=1;
    IFS0bits.CNIF=0;
}

void main(void) {
    PORTE=0;
    LATE=0;
    PORTC=0;
    LATC=0;
    TRISE=0;
    /*RC14:RC13 As Input*/
    TRISCbits.TRISC13=1;
    TRISCbits.TRISC14=1;
    /*Enable Pull-Up on Input Change*/
    CNPU1bits.CN0PUE=1;
    CNPU1bits.CN1PUE=1;
    /*Enable Change Notification 0 and 1*/
    CNEN1bits.CN0IE=1;
    CNEN1bits.CN1IE=1;
    /*Enable Change Notification Interrupt*/
    IEC0bits.CNIE=1;
    /*Change Notification Interrupt Priority 1*/
    IPC3bits.CNIP=0x01;
    /*Clear Change Notification Interrupt Flag*/
    IFS0bits.CNIF=0;
    while(1){
        LATEbits.LATE0^=1;
        __delay_ms(250);
    }
    return;
}
