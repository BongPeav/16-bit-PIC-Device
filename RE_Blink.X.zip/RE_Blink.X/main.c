/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 20, 2024, 10:45 AM
 */

#define FOSC    10000000UL
#define FCY     FOSC/4

#include <xc.h>
#include <libpic30.h>
#include "config.h"

void main(void) {
    PORTE=0;
    LATE=0;
    TRISE=0;
    
    while(1){
        LATE=0x00FF;
        __delay_ms(2000);
        LATE=0x0000;
        __delay_ms(1000);
    }
    return;
}
