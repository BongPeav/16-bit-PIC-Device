/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 26, 2024, 9:10 AM
 * Converting 1 Channel, Manual Sample Start,
 * TAD Based Conversion Start Code
 */

#define FOSC    10000000UL
#define FCY     FOSC/4

#include <xc.h>
#include <stdio.h>
#include <libpic30.h>
#include "config.h"
#include "lcd.h"

uint16_t adc_result, adc_voltage, adc_fraction;
uint8_t msg[16];

void adc_init(void){
    ADPCFG = 0xFE00; // all PORTB = analog
    ADCON1 = 0x0000; // SAMP bit = 0 ends sampling ...
    // and starts converting
    ADCHS = 0x0000; // Connect RB0/AN0 as CH0 input ..
    // in this example RB2/AN2 is the input
    ADCSSL = 0;
    ADCON3 = 0x0002; // Manual Sample, Tad = internal 2 Tcy
    ADCON2 = 0;
    ADCON1bits.ADON = 1; // turn ADC ON
}

uint16_t adc_read(uint8_t channel){
    ADCHS = channel;
    ADCON1bits.SAMP = 1; // start sampling ...
    __delay_ms(100); 
    ADCON1bits.SAMP = 0; // start Converting
    while (!ADCON1bits.DONE); // conversion done?
    return ADCBUF0;
}

void main(void) {
    lcd_init();
    lcd_clear();    
    adc_init();
    while(1){          
        adc_result = adc_read(7);
        adc_voltage = (50*adc_result)/1023;
        adc_fraction = (500*adc_result)/1023;
        sprintf(msg,"AN7: %4d %d.%d%dV",adc_result,adc_voltage/10,
                adc_voltage%10, adc_fraction%10);
        lcd_position(0,0);
        lcd_text(msg);
                
        adc_result = adc_read(8);
        adc_voltage = (50*adc_result)/1023;
        adc_fraction = (500*adc_result)/1023;
        sprintf(msg,"AN8: %4d %d.%d%dV",adc_result,adc_voltage/10,
                adc_voltage%10, adc_fraction%10);
        lcd_position(0,1);
        lcd_text(msg);
        
        __delay_ms(200);
    }
    return;
}
