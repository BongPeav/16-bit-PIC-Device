
#include "lcd.h"

void lcd_command(uint8_t command){
    uint8_t data;
    data = command>>4;
    
    LCD_PORT=data&0x000F;
    LCD_RS = 0;
    LCD_EN = 1;
    __delay_us(100);
    LCD_EN = 0;
    __delay_us(100);
    
    data = command&0x0F;  
    LCD_PORT = data&0x000F;
    LCD_RS=0;
    LCD_EN = 1;
    __delay_us(100);
    LCD_EN = 0;
    __delay_us(100);
}

void lcd_data(uint8_t command){
    uint8_t data;
    data = command>>4;
    
    LCD_PORT = data&0x000F;
    LCD_RS = 1;
    LCD_EN = 1;
    __delay_us(100);
    LCD_EN = 0;
    __delay_us(100);
    
    data = command&0x0F;
    LCD_PORT = data&0x000F;
    LCD_RS = 1;
    LCD_EN = 1;
    __delay_us(100);
    LCD_EN = 0;
    __delay_us(100);
}

void lcd_position(uint8_t x, uint8_t y){
    uint8_t vertical[]={0x80,0xC0};
    lcd_command(vertical[y]+x);
}

void lcd_text(uint8_t *text){
    while(*text) lcd_data(*text++);
}

void lcd_clear(void){
    lcd_command(0x01);
    __delay_ms(10);
    lcd_command(0x0C);
}

void lcd_init(void){
    PORTF=0;
    LATF=0;
    TRISF=0;
    LCD_PORT=0;
    PORTE=0;
    TRISE=0x0000;
    lcd_command(0x33);
    lcd_command(0x32);
    lcd_command(0x28);
    lcd_command(0x0F);
    lcd_command(0x01);
    __delay_ms(10);
    lcd_command(0x06);
    __delay_ms(10);
}
